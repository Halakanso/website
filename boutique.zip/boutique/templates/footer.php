<!-- footer -->
	<div class="row bg-dark justify-content-center mt-4 py-3">
		<footer class="text-white"> Online Clothing Shop 2023</footer>
	</div>
</div>
<script src="<?php echo $server; ?>js/script.js"></script>
</body>
</html>