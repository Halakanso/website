

existing users:
admin: name- aya
password- password

boyer : name- johny
password- yespapa

employee:name-hala
password-password

username and password of emlpoyee created by the admin (employee just log in).

import the shop1.sql file in your database
 
